package com.javalab.humaninfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HumaninfoApplication  {


	public static void main(String[] args) {
		SpringApplication.run(HumaninfoApplication.class, args);
	}


}


